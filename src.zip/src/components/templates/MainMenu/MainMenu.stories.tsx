import { MenuViewMode } from '@juki-team/commons';
import { Meta, StoryObj } from '@storybook/react-webpack5';
import { useState } from 'react';
import { action, configureActions } from 'storybook/actions';
import { Button, T } from '../../atoms';
import { AssignmentIcon, LeaderboardIcon } from '../../atoms/server';
import { MockupJukiProvider } from '../../mockup';
import { TwoContentLayout } from '../../molecules';
import { MdMathEditor, MdMathViewer } from '../../organisms';
import { SAMPLE_MD_CONTENT } from '../../organisms/MdMathViewer/constants';
import { FilterListIcon, LoadingIcon, ViewHeadlineIcon } from '../../server';
import { MainMenu as MainMenuCmp } from './MainMenu';

const meta: Meta<typeof MainMenuCmp> = {
  component: MainMenuCmp,
  argTypes: {
    menuViewMode: {
      options: [ MenuViewMode.HORIZONTAL, MenuViewMode.VERTICAL ],
      control: { type: 'radio' },
    },
  },
  render: ({ menuViewMode }) => (
    <MockupJukiProvider>
      <div style={{ height: '500px' }}>
        <MainMenuCmp
          menu={menu}
          onSeeMyProfile={() => console.info('onSeeMyProfile')}
          menuViewMode={menuViewMode}
          multiCompanies
          profileSelected={true}
          moreApps={
            <>
              <div className="jk-row">
                <div style={{ width: 95 }}>
                  {/*<JukiCouchLogoHorImage />*/}
                </div>
                <LoadingIcon size="small" /> <T className="tt-se">developing</T>
                ...
              </div>
              <div className="jk-row">
                <div style={{ width: 95 }}>
                  {/*<JukiUtilsLogoHorImage />*/}
                </div>
                <LoadingIcon size="small" /> <T className="tt-se">developing</T>
                ...
              </div>
            </>
          }
        >
          <div className="jk-pg-lg ow-ao ht-100">
            <div className="bc-we jk-pg">
              <MdMathViewer source={SAMPLE_MD_CONTENT} />
            </div>
            <div className="bc-we">
              <MdMathEditor
                value={SAMPLE_MD_CONTENT}
                onChange={() => {
                }}
                informationButton
              />
            </div>
          </div>
        </MainMenuCmp>
      </div>
    </MockupJukiProvider>
  ),
};

export default meta;

type Story = StoryObj<typeof MainMenuCmp>;

configureActions({
  depth: 100,
  // Limit the number of items logged into the actions panel
  limit: 20,
});

const menu = [
  {
    label: 'contests',
    icon: <ViewHeadlineIcon size="small" />,
    tooltipLabel: 'contests',
    selected: true,
    onClick: () => action('/contests'),
  },
  {
    label: 'problems',
    icon: <AssignmentIcon size="small" />,
    selected: false,
    onClick: () => action('/problems'),
  },
  {
    label: 'ranking',
    icon: <LeaderboardIcon size="small" />,
    selected: false,
    onClick: () => action('/admin'),
  },
  {
    label: 'admin',
    icon: <FilterListIcon size="small" />,
    selected: false,
    onClick: () => action('/admin'),
  },
];

export const MainMenu: Story = {
  args: {},
};

const Cmp = ({ menuViewMode }: { menuViewMode?: MenuViewMode }) => {
  const [ index, setIndex ] = useState(0);
  return (
    <MockupJukiProvider>
      <div style={{ height: '100VH' }}>
        <MainMenuCmp
          menu={menu.map((item, i) => ({ ...item, selected: i === index }))}
          onSeeMyProfile={() => console.info('onSeeMyProfile')}
          menuViewMode={menuViewMode}
          multiCompanies
          moreApps={
            <>
              <div className="jk-row">
                <div style={{ width: 95 }}>
                  {/*<JukiCouchLogoHorImage />*/}
                </div>
                <LoadingIcon size="small" /> <T className="tt-se">developing</T>
                ...
              </div>
              <div className="jk-row">
                <div style={{ width: 95 }}>
                  {/*<JukiUtilsLogoHorImage />*/}
                </div>
                <LoadingIcon size="small" /> <T className="tt-se">developing</T>
                ...
              </div>
            </>
          }
        >
          <TwoContentLayout loading breadcrumbs={[ <div>a</div> ]}>
            <h1>Title 1</h1>
            <Button
              onClick={() => {
                setIndex((index + 1) % menu.length);
              }}
            >
              click
            </Button>
          </TwoContentLayout>
        </MainMenuCmp>
      </div>
    </MockupJukiProvider>
  );
};

export const MainMenuLoading: Story = {
  render: ({ menuViewMode }) => (
    <Cmp menuViewMode={menuViewMode} />
  ),
};
