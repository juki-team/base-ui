export interface NewVersionAvailableProps {
  apiVersionUrl: string,
}
