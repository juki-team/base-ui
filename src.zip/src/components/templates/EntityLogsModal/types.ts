import type { BasicModalProps } from '../../atoms/types';

export interface EntityLogsModalProps extends BasicModalProps {
  url: string,
}
