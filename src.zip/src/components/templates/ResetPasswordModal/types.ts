import { BasicModalProps } from '../../atoms/Modal/types';

export interface ResetPasswordModalProps extends BasicModalProps {
  nickname: string,
  companyKey: string,
}
