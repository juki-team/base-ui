import { ContestSummaryListResponseDTO } from '@juki-team/commons';
import { TableHeadFieldProps } from '../../organisms/_layz_/DataViewer/types';

type TableHeadFieldContestSummaryListResponseDTOProps = TableHeadFieldProps<ContestSummaryListResponseDTO>;

export type ContestNameLinkFieldProps = TableHeadFieldContestSummaryListResponseDTOProps;
