import { PropsWithChildren } from 'react';

export type PortalProps = PropsWithChildren<{ className?: string, el?: string }>;
