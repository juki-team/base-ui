export type { TextAreaProps } from './TextArea';
