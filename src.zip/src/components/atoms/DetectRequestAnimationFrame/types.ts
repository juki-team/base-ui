export interface DetectRequestAnimationFrameProps {
  name?: string,
}
