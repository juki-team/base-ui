import { PropsWithChildren } from 'react';

export type ClientProps = PropsWithChildren;
