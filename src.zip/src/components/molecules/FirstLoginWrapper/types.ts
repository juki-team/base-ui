import { PropsWithChildren } from 'react';

export type FirstLoginWrapperProps = PropsWithChildren;
