import { PawsLoadingLayout } from './PawsLoadingLayout';

export const JukiLoadingLayout = PawsLoadingLayout;
