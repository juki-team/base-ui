export interface HomeLinkProps {
}
