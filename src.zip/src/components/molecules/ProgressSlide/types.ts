export interface ProgressSlideProps {
  height?: number,
  progress?: number,
  color?: string,
  className?: string,
}
