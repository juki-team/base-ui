import { ReactNode } from 'react';

export interface TwoContentSectionProps {
  children: [ ReactNode, ReactNode ],
  className?: string,
}
