export interface ThemeColorPaletteProps {
}
