export interface SubmissionRejudgeButtonProps {
  submissionId: string;
}
