import { ProblemVerdict } from '@juki-team/commons';

export interface ProblemVerdictTagProps {
  verdict: ProblemVerdict,
  small?: boolean
}
