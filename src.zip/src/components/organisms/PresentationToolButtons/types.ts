export interface PresentationToolButtonsProps {
}
