import { CSSProperties, PropsWithChildren } from 'react';

export interface PageNotFoundProps extends PropsWithChildren {
  style?: CSSProperties,
}
