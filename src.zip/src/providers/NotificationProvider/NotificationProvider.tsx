import { useReducer } from 'react';
import { CardNotification } from '../../components/organisms/CardNotification/CardNotification';
import { NotificationContext } from '../../components/organisms/CardNotification/context';
import {
  NotificationAction,
  NotificationActionsTypes,
  NotificationProps,
  NotificationProviderProps,
} from '../../components/organisms/CardNotification/types';
import { NotificationType } from '../../enums';
import { usePageStore } from '../../stores/page/usePageStore';
import { useSoundStore } from '../../stores/sound/useSoundStore';

export function NotificationProvider({ children }: NotificationProviderProps) {
  
  const sound = useSoundStore();
  
  const [ state, dispatch ] = useReducer((state: NotificationProps[], action: NotificationActionsTypes) => {
    switch (action.type) {
      case NotificationAction.ADD_NOTIFICATION:
        if (action.payload.type === NotificationType.SUCCESS && !action.payload.silent) {
          void sound.playSuccess();
        }
        if (action.payload.type === NotificationType.INFO && !action.payload.silent) {
          void sound.playNotification();
        }
        if (action.payload.type === NotificationType.ERROR && !action.payload.silent) {
          void sound.playError();
        }
        if (action.payload.type === NotificationType.WARNING && !action.payload.silent) {
          void sound.playWarning();
        }
        return [ ...state, { ...action.payload } ];
      case NotificationAction.REMOVE_NOTIFICATION:
        return state.filter(notification => notification.id !== action.notificationId);
      default:
        return state;
    }
  }, []);
  
  const viewPortSize = usePageStore(store => store.viewPort.size);
  
  const notificationsFiltered = state.filter(note => note.type !== NotificationType.QUIET);
  
  const notifications = viewPortSize === 'sm' ? [ ...notificationsFiltered ].reverse() : notificationsFiltered;
  
  const chunkStates = notifications.length ? [ [ notifications[0]! ] ] : [];
  for (let i = 1; i < notifications.length; i++) {
    if (chunkStates[chunkStates.length - 1]![0]?.type === notifications[i]!.type) {
      chunkStates[chunkStates.length - 1]!.push(notifications[i]!);
    } else {
      chunkStates.push([ notifications[i]! ]);
    }
  }
  
  return (
    <NotificationContext.Provider value={{ dispatch }}>
      {children}
      <div className="notification-wrapper">
        {chunkStates
          .map((chunk) => (
            <CardNotification
              key={chunk[0]!.id}
              ids={chunk.map(({ id }) => id)}
              message={
                <div className="jk-col gap">
                  {chunk.map((note) => <div key={note.id}>{note.message}</div>)}
                </div>
              }
              type={chunk[0]!.type}
            />
          ))}
      </div>
      <div className="notification-wrapper-quiet">
        {state
          .filter(note => note.type === NotificationType.QUIET)
          .map((note) => (
            <CardNotification key={note.id} ids={[ note.id ]}{...note} type={NotificationType.QUIET} />
          ))}
      </div>
    </NotificationContext.Provider>
  );
}
