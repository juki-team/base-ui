import { ApiManager } from './ApiManager';
import { AppRoutes } from './AppRoutes';

export const jukiApiManager = new ApiManager();
export const jukiAppRoutes = new AppRoutes();
// export const jukiGlobalStore = new GlobalStore()
