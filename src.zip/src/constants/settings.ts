export const JUKI_SERVICE_V1_URL = process.env.NEXT_PUBLIC_JUKI_SERVICE_V1_URL || '';
export const JUKI_SERVICE_V2_URL = process.env.NEXT_PUBLIC_JUKI_SERVICE_V2_URL || '';
export const JUKI_SOCKET_BASE_URL = process.env.NEXT_PUBLIC_JUKI_SOCKET_BASE_URL || '';
export const JUKI_TOKEN_NAME = process.env.NEXT_PUBLIC_JUKI_TOKEN_NAME || '';
export const NODE_ENV = process.env.NODE_ENV || 'development';
